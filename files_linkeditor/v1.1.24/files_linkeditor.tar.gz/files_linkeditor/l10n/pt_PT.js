OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Não pode abrir a pasta",
    "This file is too big to be opened. Please download the file instead." : "Este ficheiro é demasiado grande para ser aberto. Em vez disso, por favor, transfira o ficheiro.",
    "Cannot read the file." : "Não é possível ler o ficheiro.",
    "Invalid file path supplied." : "O Caminho do ficheiro indicado é inválido.",
    "The file is locked." : "O ficheiro está bloqueado.",
    "An internal server error occurred." : "Ocorreu um erro interno no servidor.",
    "You can not write to a folder" : "Não é possível escrever na pasta",
    "Cannot save file as it has been modified since opening" : "Não é possível guardar o ficheiro porque este foi modificado desde a abertura",
    "Insufficient permissions" : "Permissões insuficientes",
    "File path not supplied" : "Caminho do ficheiro não indicado",
    "File mtime not supplied" : "O Ficheiro mtime não foi indicado",
    "An error occurred!" : "Ocorreu um erro!",
    "Cancel" : "Cancelar",
    "Save" : "Guardar"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
