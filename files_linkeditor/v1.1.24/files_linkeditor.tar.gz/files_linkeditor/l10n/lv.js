OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Tu nevari atvērt mapi",
    "This file is too big to be opened. Please download the file instead." : "Šī datne ir pārāk liela, lai to atvērtu. Lūgums lejupielādēt šo datni.",
    "Cannot read the file." : "Nevar nolasīt datni.",
    "Invalid file path supplied." : "Norādīts nederīgs datnes ceļš.",
    "The file is locked." : "Datne ir slēgta.",
    "An internal server error occurred." : "Atgadījās iekšēja servera kļūda.",
    "Insufficient permissions" : "Nepietiekamas atļaujas",
    "File path not supplied" : "Nav norādīts datnes ceļš",
    "An error occurred!" : "Gadījās kļūda!",
    "Cancel" : "Atcelt",
    "Save" : "Saglabāt",
    "Open in same window" : "Atvērt tajā pašā logā"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
