OC.L10N.register(
    "files_linkeditor",
    {
    "This file is too big to be opened. Please download the file instead." : "Tệp này quá lớn để mở. Vui lòng tải xuống thay vì mở trực tiếp.",
    "Cannot read the file." : "Không thể đọc thư mục",
    "Invalid file path supplied." : "Đường dẫn tệp không hợp lệ được cung cấp",
    "The file is locked." : "Thư mục đã khóa",
    "An internal server error occurred." : "Đã xảy ra lỗi máy chủ nội bộ.",
    "Insufficient permissions" : "Không đủ quyền",
    "An error occurred!" : "Có một lỗi đã xảy ra!",
    "Cancel" : "Hủy",
    "Save" : "Lưu"
},
"nplurals=1; plural=0;");
