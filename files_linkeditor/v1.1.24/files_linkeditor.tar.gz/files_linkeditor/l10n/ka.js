OC.L10N.register(
    "files_linkeditor",
    {
    "This file is too big to be opened. Please download the file instead." : "This file is too big to be opened. Please download the file instead.",
    "Cannot read the file." : "Cannot read the file.",
    "Invalid file path supplied." : "Invalid file path supplied.",
    "The file is locked." : "The file is locked.",
    "An internal server error occurred." : "An internal server error occurred.",
    "An error occurred!" : "An error occurred!",
    "Cancel" : "Cancel",
    "Save" : "Save"
},
"nplurals=2; plural=(n!=1);");
