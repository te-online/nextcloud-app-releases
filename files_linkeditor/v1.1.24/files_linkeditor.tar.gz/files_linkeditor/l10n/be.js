OC.L10N.register(
    "files_linkeditor",
    {
    "This file is too big to be opened. Please download the file instead." : "Гэты файл занадта вялікі, каб яго можна было адкрыць. Замест гэтага спампуйце файл.",
    "Cannot read the file." : "Немагчыма прачытаць файл.",
    "The file is locked." : "Файл заблакіраваны.",
    "An internal server error occurred." : "Узнікла ўнутраная памылка сервера.",
    "Edit link" : "Рэдагаваць спасылку",
    "New link" : "Новая спасылка",
    "Cancel" : "Скасаваць",
    "Save" : "Захаваць"
},
"nplurals=4; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<12 || n%100>14) ? 1 : n%10==0 || (n%10>=5 && n%10<=9) || (n%100>=11 && n%100<=14)? 2 : 3);");
