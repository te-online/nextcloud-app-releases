OC.L10N.register(
    "files_linkeditor",
    {
    "Cannot save file as it has been modified since opening" : "Faylı saxlamaq mümkün deyil cünki, açılma müddətində dəyişdirilib",
    "Insufficient permissions" : "Qeyri kafi yetkilər",
    "File path not supplied" : "Fayl ünvanı təqdim edilmir",
    "File mtime not supplied" : "Faylda dəyişmə vaxtı göstərilmir",
    "An error occurred!" : "Səhv baş verdi!",
    "Cancel" : "Dayandır",
    "Save" : "Saxla"
},
"nplurals=2; plural=(n != 1);");
