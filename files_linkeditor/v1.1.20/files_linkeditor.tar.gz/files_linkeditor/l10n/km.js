OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "មានបញ្ហា​មួយ​កើតឡើង!",
    "Cancel" : "បោះបង់",
    "Save" : "រក្សាទុក"
},
"nplurals=1; plural=0;");
