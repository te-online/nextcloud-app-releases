OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "Ralat berlaku!",
    "Cancel" : "Batal",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
