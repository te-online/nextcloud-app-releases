OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "Il occurreva un error!",
    "Cancel" : "Cancellar",
    "Save" : "Salveguardar"
},
"nplurals=2; plural=(n != 1);");
