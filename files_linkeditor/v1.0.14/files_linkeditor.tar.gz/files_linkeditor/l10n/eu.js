OC.L10N.register(
        'files_linkeditor',
        {
                'You are about to visit:': 'Webgune honetara nabigatzera zoaz:',
                'Saving failed!': 'Errorea gordetzean',
                'Edit link': 'Editatu esteka',
                'View link': 'Ikusi esteka',
                'This link-file doesn\'t seem to be valid. – You can fix this by editing the file.': 'Fitxategi honek arazo bat duela dirudi. Fitxategia editatuz konpondu dezakezu.',
                'A slight problem': 'Arazotxo bat',
                'Cancel': 'Utzi',
                'Visit link': 'Bisitatu esteka',
                'An error occurred!': 'Errore bat gertatu da!',
                'Link target URL': 'Sartu helburuko URLa',
                'e.g. https://example.org': 'Adibidez, https://adibidea.eus',
                'Save': 'Gorde',
                'New link': 'Esteka berria',
                'Link.URL': 'Esteka.URL'
        },
'nplurals=2; plural=(n != 1);');
