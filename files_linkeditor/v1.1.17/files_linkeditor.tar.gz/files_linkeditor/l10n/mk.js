OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Не можете да отворите папка",
    "This file is too big to be opened. Please download the file instead." : "Датотеката е премногу голема за да се отвори. Преземете ја датотеката и отворете ја.",
    "Cannot read the file." : "Неможе да се прочита датотеката.",
    "The file is locked." : "Датотеката е заклучена.",
    "An internal server error occurred." : "Се случи внатрешна грешка.",
    "An error occurred!" : "Се случи грешка",
    "Saving failed!" : "Неуспешно зачувување!",
    "Cancel" : "Откажи",
    "Save" : "Зачувај"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
