OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "ದೋಷ ಕಂಡುಬಂದಿದೆ!",
    "Cancel" : "﻿ರದ್ದು",
    "Save" : "﻿ಉಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
