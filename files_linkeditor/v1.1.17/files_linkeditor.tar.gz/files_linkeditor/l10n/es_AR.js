OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "No puede abrir la carpeta",
    "This file is too big to be opened. Please download the file instead." : "Este archivo es demasiado grande para ser abierto. Favor de descargarlo en su lugar.",
    "Cannot read the file." : "No es posible leer el archivo.",
    "Invalid file path supplied." : "La ruta del archivo proporcionada es inválida.",
    "The file is locked." : "El archivo está bloqueado.",
    "An internal server error occurred." : "Se presentó un error interno en el servidor. ",
    "You can not write to a folder" : "No puede escribir a la carpeta",
    "Cannot save file as it has been modified since opening" : "No es posible guardar el archivo ya que ha sido modificado desde que fue abierto",
    "Insufficient permissions" : "Permisos insuficientes",
    "File path not supplied" : "La ruta del archivo no fue proporcionada",
    "File mtime not supplied" : "El archivo mtime no fue proporcionado",
    "An error occurred!" : "¡Se presentó un error!",
    "Cancel" : "Cancelar",
    "Save" : "Guardar"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
