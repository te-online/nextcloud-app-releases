OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "Gadījās kļūda!",
    "Cancel" : "Atcelt",
    "Save" : "Saglabāt"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
