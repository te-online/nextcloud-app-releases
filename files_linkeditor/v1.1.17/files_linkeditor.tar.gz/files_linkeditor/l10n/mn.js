OC.L10N.register(
    "files_linkeditor",
    {
    "Cancel" : "болиулах",
    "Save" : "Хадгалах"
},
"nplurals=2; plural=(n != 1);");
