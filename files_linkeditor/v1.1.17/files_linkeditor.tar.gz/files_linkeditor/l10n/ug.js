OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "خاتالىق كۆرۈلدى!",
    "Cancel" : "ۋاز كەچ",
    "Save" : "ساقلا"
},
"nplurals=2; plural=(n != 1);");
