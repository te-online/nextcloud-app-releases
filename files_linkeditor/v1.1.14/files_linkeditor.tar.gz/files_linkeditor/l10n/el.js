OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Δεν μπορείτε να ανοίξετε ένα φάκελο",
    "This file is too big to be opened. Please download the file instead." : "Αυτό το αρχείο είναι πολύ μεγάλο για να ανοιχθεί. Αντί αυτού, παρακαλούμε κάντε λήψη του αρχείου.",
    "Cannot read the file." : "Αδυναμία ανάγνωσης αρχείου.",
    "Invalid file path supplied." : "Έχει δοθεί άκυρη διαδρομή για το αρχείο.",
    "The file is locked." : "Το αρχείο είναι κλειδωμένο.",
    "An internal server error occurred." : "Προέκυψε ένα εσωτερικό σφάλμα διακομιστή.",
    "You can not write to a folder" : "Δεν μπορείτε να γράψετε στον φάκελο",
    "Cannot save file as it has been modified since opening" : "Δεν είναι δυνατή η αποθήκευση του αρχείου, όπως έχει τροποποιηθεί από το άνοιγμα.",
    "Insufficient permissions" : "Μη επαρκή δικαιώματα",
    "File path not supplied" : "Η διαδρομή του αρχείου δεν παρέχεται.",
    "File mtime not supplied" : "Ο χρόνος τροποποίησης  του αρχείου δεν παρέχεται",
    "An error occurred!" : "Παρουσιάστηκε σφάλμα!",
    "Saving failed!" : "Απέτυχε η αποθήκευση!",
    "Cancel" : "Ακύρωση",
    "Save" : "Αποθήκευση"
},
"nplurals=2; plural=(n != 1);");
