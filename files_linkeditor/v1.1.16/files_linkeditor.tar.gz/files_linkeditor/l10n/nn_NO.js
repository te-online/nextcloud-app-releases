OC.L10N.register(
    "files_linkeditor",
    {
    "This file is too big to be opened. Please download the file instead." : "Fila er for stor for å opnast. Ver venleg å laste ned fila i staden for.",
    "Cannot read the file." : "Kan ikkje lesa fila.",
    "Invalid file path supplied." : "Ugyldig stig oppgjett.",
    "The file is locked." : "Fila er låst.",
    "An internal server error occurred." : "Det oppstod ein intern tenarfeil.",
    "An error occurred!" : "Det oppstod ein feil.",
    "Cancel" : "Avbryt",
    "Save" : "Lagre"
},
"nplurals=2; plural=(n != 1);");
