OC.L10N.register(
    "files_linkeditor",
    {
    "The file is locked." : "El ficheru ta bloquiáu.",
    "An internal server error occurred." : "Prodúxose un error internu del sirvidor.",
    "An error occurred!" : "¡Prodúxose un error!"
},
"nplurals=2; plural=(n != 1);");
