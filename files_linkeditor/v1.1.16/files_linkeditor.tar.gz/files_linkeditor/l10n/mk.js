OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Не можете да отворите папка",
    "Cannot read the file." : "Неможе да се прочита датотеката.",
    "An error occurred!" : "Се случи грешка",
    "Saving failed!" : "Неуспешно зачувување!",
    "Cancel" : "Откажи",
    "Save" : "Зачувај"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
