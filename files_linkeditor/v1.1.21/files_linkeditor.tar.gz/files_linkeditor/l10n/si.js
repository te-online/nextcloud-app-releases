OC.L10N.register(
    "files_linkeditor",
    {
    "Cancel" : "අවලංගු කරන්න",
    "Save" : "සුරකින්න"
},
"nplurals=2; plural=(n != 1);");
