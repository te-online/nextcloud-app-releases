OC.L10N.register(
    "files_linkeditor",
    {
    "Cancel" : "Cancel",
    "Save" : "Save"
},
"nplurals=1; plural=0;");
