OC.L10N.register(
    "files_linkeditor",
    {
    "Cancel" : "Sefsex",
    "Save" : "Sekles"
},
"nplurals=2; plural=(n != 1);");
