OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Ju nuk mund të hapni një dosje",
    "This file is too big to be opened. Please download the file instead." : "Kjo kartelë është shumë e madhe për hapje. Ju lutemi, në vend të kësaj, shkarkojeni.",
    "Cannot read the file." : "S’lexohet dot kartela.",
    "Invalid file path supplied." : "U dha shteg i pavlefshëm.",
    "The file is locked." : "Kartela është e kyçur.",
    "An internal server error occurred." : "Ndodhi një gabim i brendshëm shërbyesi.",
    "You can not write to a folder" : "Ju s'mund të shkruani tek një dosje ",
    "Cannot save file as it has been modified since opening" : "S’ruhet dot kartela, ngaqë është ndryshuar që prej hapjes",
    "Insufficient permissions" : "Leje të pamjaftueshme",
    "File path not supplied" : "S’u dha shteg kartele",
    "File mtime not supplied" : "S’u dha skedari mtime",
    "An error occurred!" : "Ndodhi një gabim!",
    "Cancel" : "Anullo",
    "Save" : "Ruaj"
},
"nplurals=2; plural=(n != 1);");
