OC.L10N.register(
    "files_linkeditor",
    {
    "You can not open a folder" : "Nun pues abrir una carpeta",
    "Cannot read the file." : "Nun se pue lleer el ficheru.",
    "The file is locked." : "El ficheru ta bloquiáu.",
    "An internal server error occurred." : "Prodúxose un error internu del sirvidor.",
    "You can not write to a folder" : "Nun se pue escribir una carpeta",
    "An error occurred!" : "¡Prodúxose un error!",
    "Edit link" : "Editar l'enllaz",
    "Cancel" : "Encaboxar",
    "Save" : "Guardar"
},
"nplurals=2; plural=(n != 1);");
