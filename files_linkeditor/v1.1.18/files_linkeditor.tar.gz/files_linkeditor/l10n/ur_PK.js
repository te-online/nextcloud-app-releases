OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "ایک خرابی واقع ہوئی!",
    "Cancel" : "منسوخ کریں",
    "Save" : "حفظ"
},
"nplurals=2; plural=(n != 1);");
