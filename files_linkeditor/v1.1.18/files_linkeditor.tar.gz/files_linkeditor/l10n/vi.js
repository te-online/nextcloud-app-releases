OC.L10N.register(
    "files_linkeditor",
    {
    "Insufficient permissions" : "Không đủ quyền",
    "An error occurred!" : "Có một lỗi đã xảy ra!",
    "Cancel" : "Hủy",
    "Save" : "Lưu"
},
"nplurals=1; plural=0;");
