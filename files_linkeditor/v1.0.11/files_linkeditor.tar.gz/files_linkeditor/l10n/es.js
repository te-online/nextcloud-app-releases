OC.L10N.register(
        'files_linkeditor',
        {
                'You are about to visit:': 'Está a punto de visitar:',
                'Saving failed!': 'Error al guardar',
                'Edit link': 'Editar enlace',
                'View link': 'Ver enlace',
                'This link-file doesn\'t seem to be valid. – You can fix this by editing the file.': 'Este archivo/enlace no parece ser valido, puede reparar esto editando el archivo.',
                'A slight problem': 'Se ha producido un fallo',
                'Cancel': 'Cancelar',
                'Visit link': 'Visitar enlace',
                'An error occurred!': 'Ha ocurrido un error',
                'Link target URL': 'Inserta la dirección de destino',
                'e.g. https://example.org': 'Ej. https://example.org',
                'Save': 'Guardar',
                'New link': 'Nuevo enlace',
                'Link.URL': 'Link.URL'
        },
'nplurals=2; plural=(n != 1);');
