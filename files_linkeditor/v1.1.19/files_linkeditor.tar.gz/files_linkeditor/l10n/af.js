OC.L10N.register(
    "files_linkeditor",
    {
    "Saving failed!" : "Stoor het misluk!",
    "Cancel" : "Kanselleer",
    "Save" : "Bewaar"
},
"nplurals=2; plural=(n != 1);");
