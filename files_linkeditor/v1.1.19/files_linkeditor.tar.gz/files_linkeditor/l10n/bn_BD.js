OC.L10N.register(
    "files_linkeditor",
    {
    "An error occurred!" : "সমস্যা দেখা দিয়েছে !",
    "Cancel" : "বাতির",
    "Save" : "সংরক্ষণ"
},
"nplurals=2; plural=(n != 1);");
