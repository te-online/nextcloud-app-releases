OC.L10N.register(
    "files_linkeditor",
    {
    "Cancel" : "ýatyrmak",
    "Save" : "Saklamak"
},
"nplurals=2; plural=(n != 1);");
