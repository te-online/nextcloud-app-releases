OC.L10N.register(
    "files_linkeditor",
    {
    "Cancel" : "ຍົກເລີກ",
    "Save" : "ບັນທຶກ"
},
"nplurals=1; plural=0;");
